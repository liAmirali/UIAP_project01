package Exepctions;

public class DoctorPersonnelIDNotExistsException extends Exception {
    public DoctorPersonnelIDNotExistsException(String message) {
        super(message);
    }
}
