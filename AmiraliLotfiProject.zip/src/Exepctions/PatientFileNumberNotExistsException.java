package Exepctions;

public class PatientFileNumberNotExistsException extends Exception {
    public PatientFileNumberNotExistsException(String message) {
        super(message);
    }
}
